﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TestAppln.ViewModel
{
    public interface IViewModelBase
    {
        event PropertyChangedEventHandler PropertyChanged;
    }

    /// <summary>
    /// Base View model
    /// </summary>
    public abstract class ViewModelBase : INotifyPropertyChanged, IViewModelBase
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
    
    /// <summary>
    /// 
    /// </summary>
    public class RelayCommand : ICommand
    {
        private Action<object> execute;
        private Func<object, bool> canExecute;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return this.canExecute == null || this.canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            this.execute(parameter);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class UIControlViewModel
    {        
        public string ControlName
        {
            get;
            set;
        }
        public int Index { get; internal set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class ButtonViewModel : UIControlViewModel
    {
        public ButtonViewModel() { ControlName = "Button"; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class TextBoxViewModel : UIControlViewModel
    {
        public TextBoxViewModel() { ControlName = "TextBox"; }
    }

    public class TextBlockViewModel : UIControlViewModel
    {
        public TextBlockViewModel() { ControlName = "TextBlock"; }
    }

    public class LabelViewModel : UIControlViewModel
    {
        public LabelViewModel() { ControlName = "Label"; }
    }

    public class CheckboxViewModel : UIControlViewModel
    {
        public CheckboxViewModel() { ControlName = "Checkbox"; }
    }

    public class CombokBoxViewModel : UIControlViewModel
    {
        public CombokBoxViewModel() { ControlName = "ComboBox"; }
    }

    public class DataGridViewModel : UIControlViewModel
    {
        public DataGridViewModel() { ControlName = "DataGrid"; }
    }

    public class ListBoxViewModel : UIControlViewModel
    {
        public ListBoxViewModel() { ControlName = "ListBox"; }
    }

    public enum ControlType
    {
        Button,
        ComboBox,
        ListBox,
        DataGrid,
        TextBox,
        TextBlock,
        Checkbox,
        Label
    }
    public class MainViewModel:ViewModelBase
    {
        private ObservableCollection<UIControlViewModel> _controls = new ObservableCollection<UIControlViewModel>();
        private ObservableCollection<UIControlViewModel> _addedControls = new ObservableCollection<UIControlViewModel>();

        public MainViewModel()
        {
            AddCommand = new RelayCommand((param) => OnAddControl(param), (r) => true) ;            
        }        
        
        private void OnAddControl(object param)
        {
            if (param is not null)
            {
                ControlType cntrl = (ControlType)Enum.Parse(typeof(ControlType), param.ToString());
                var index = AddedControls.Count;
                switch (cntrl)
                {
                    case ControlType.Button:
                        AddedControls.Add(new ButtonViewModel() { Index = index});
                        break;

                    case ControlType.Label:
                        AddedControls.Add(new LabelViewModel() { Index = index });
                        break;

                    case ControlType.TextBlock:
                        AddedControls.Add(new TextBlockViewModel() { Index = index });
                        break;

                    case ControlType.TextBox:
                        AddedControls.Add(new TextBoxViewModel() { Index = index });
                        break;

                    case ControlType.Checkbox:
                        AddedControls.Add(new CheckboxViewModel() { Index = index });
                        break;

                    case ControlType.ComboBox:
                        AddedControls.Add(new CombokBoxViewModel() { Index = index });
                        break;


                    case ControlType.ListBox:
                        AddedControls.Add(new ListBoxViewModel() { Index = index });
                        break;

                    case ControlType.DataGrid:
                        AddedControls.Add(new DataGridViewModel() { Index = index });
                        break;

                }                
            }
        }        

        public ObservableCollection<UIControlViewModel> AddedControls
        {
            get { return _addedControls; }
            set { _addedControls = value;}
        }

        public RelayCommand AddCommand { get; set; }
    }
}
