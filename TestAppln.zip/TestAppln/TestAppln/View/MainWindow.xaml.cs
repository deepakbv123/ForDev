﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TestAppln.ViewModel;

namespace TestAppln
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            var vm = new MainViewModel();
            this.DataContext = vm;
            vm.AddedControls.CollectionChanged += AddedControls_CollectionChanged;
        }
              

        private void AddedControls_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            var sv = Utilities.FindScrollViewer(listbox1);
            if(e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add &&
                e.NewStartingIndex == listbox1.Items.Count-1)
            sv.ScrollToBottom();
           
        }
             
        void MouseRightButtonDownEventHandler(object sender, MouseButtonEventArgs e)
        {
           if(sender is ListBoxItem)
            {
                ListBoxItem draggedItem = sender as ListBoxItem;
                DragDrop.DoDragDrop(draggedItem, draggedItem, DragDropEffects.All);
            }
            
        }       

        void DropEventHandler(object sender, DragEventArgs e)
        {
            ListBoxItem droppedData = e.Data.GetData(typeof(ListBoxItem)) as ListBoxItem;
            UIControlViewModel target = ((ListBoxItem)(sender)).DataContext as UIControlViewModel;
            var movingControl = droppedData.DataContext as UIControlViewModel;
            var vm = this.DataContext as MainViewModel;

            int removedIdx = movingControl.Index;
            int targetIdx = target.Index;
            vm.AddedControls.RemoveAt(removedIdx);
            vm.AddedControls.Insert(targetIdx, movingControl);

            movingControl.Index = targetIdx;
            target.Index = removedIdx;
        }
               

        private void TextBox_PreviewDragOver(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.All;
            e.Handled = true;
        }        
    }

    public class Utilities
    {
        public static ScrollViewer FindScrollViewer(DependencyObject root)
        {
            var queue = new Queue<DependencyObject>(new[] { root });

            do
            {
                var item = queue.Dequeue();

                if (item is ScrollViewer)
                    return (ScrollViewer)item;

                for (var i = 0; i < VisualTreeHelper.GetChildrenCount(item); i++)
                    queue.Enqueue(VisualTreeHelper.GetChild(item, i));
            } while (queue.Count > 0);

            return null;
        }
    }
}
