﻿-Single click on the control to add it to the  container window on the right side.

-Right click on the drawn control and drag it to move between the rows